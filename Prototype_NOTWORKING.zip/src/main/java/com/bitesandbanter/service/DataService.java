package com.bitesandbanter.service;

import com.bitesandbanter.datastructure.PriorityQueue;
import com.bitesandbanter.datastructure.Stack;
import com.bitesandbanter.model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Singleton service layer: Holds all application data and core business logic.
 */
public class DataService {
    private static DataService instance;
    
    public static DataService getInstance() {
        if (instance == null) { 
            instance = new DataService(); 
        }
        return instance;
    }

    // Core Application State
    private final ObservableList<Product> menuItems = FXCollections.observableArrayList();
    private final Map<String, InventoryItem> inventory = new HashMap<>();
    private final PriorityQueue orderQueue = new PriorityQueue();
    private final List<Order> orderHistory = new ArrayList<>();
    private final Stack<AdminAction> undoStack = new Stack<>();
    private final AtomicInteger orderCounter = new AtomicInteger(1);
    
    // Enhanced user management with roles
    private final Map<String, User> users = new HashMap<>();
    private User currentUser;

    private DataService() { 
        loadInitialData(); 
    }

    private void loadInitialData() {
        // Initialize users
        users.put("admin", new User("admin", "admin123", "ADMIN"));
        users.put("staff", new User("staff", "staff123", "STAFF"));
        
        // Menu Items
        menuItems.addAll(Arrays.asList(
            new Product("menu-1", "Cheese Burger", 70.00, "Juicy beef patty with cheese", 
                        Map.of("Beef Patties", 1, "Buns", 1, "Cheese Slices", 1),
                        "/images/burger.jpg"),
            new Product("menu-2", "French Fries", 100.00, "Crispy golden fries", 
                        Map.of("French Fries", 1),
                        "/images/fries.jpg"),
            new Product("menu-3", "Soft Drink", 50.00, "Refreshing cold soda", 
                        Map.of("Soda Syrup", 1),
                        "/images/soda.jpg"),
            new Product("menu-4", "Combo Meal", 250.00, "Burger, fries and drink", 
                        Map.of("Beef Patties", 1, "Buns", 1, "Cheese Slices", 1, "French Fries", 1, "Soda Syrup", 1),
                        "/images/combo.jpg")
        ));
        
        // Inventory Items
        inventory.put("Beef Patties", new InventoryItem("Beef Patties", 50, 25));
        inventory.put("Buns", new InventoryItem("Buns", 50, 25));
        inventory.put("Cheese Slices", new InventoryItem("Cheese Slices", 50, 25));
        inventory.put("French Fries", new InventoryItem("French Fries", 50, 25));
        inventory.put("Soda Syrup", new InventoryItem("Soda Syrup", 50, 25));
        inventory.put("Bacons", new InventoryItem("Bacons", 30, 15));
        inventory.put("Onions", new InventoryItem("Onions", 40, 20));
        inventory.put("Pickles", new InventoryItem("Pickles", 35, 15));
    }
    
    // === AUTHENTICATION ===
    public boolean authenticateUser(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            currentUser = user;
            return true;
        }
        return false;
    }
    
    public void logout() {
        currentUser = null;
    }
    
    public User getCurrentUser() {
        return currentUser;
    }
    
    public boolean isAdmin() {
        return currentUser != null && "ADMIN".equals(currentUser.getRole());
    }
    
    // === ORDER MANAGEMENT ===
    public Optional<Order> placeOrder(List<OrderItem> items) {
        if (items == null || items.isEmpty()) {
            return Optional.empty();
        }
        
        // Calculate priority based on total items
        int totalItems = items.stream().mapToInt(OrderItem::getQuantity).sum();
        int priority = (totalItems >= 5) ? 1 : ((totalItems >= 3) ? 2 : 3);
        
        // Calculate total
        double total = items.stream().mapToDouble(OrderItem::getSubTotal).sum();
        
        // Generate order ID
        String orderId = String.format("ORD-%03d", orderCounter.getAndIncrement());
        
        // Create and enqueue order
        Order newOrder = new Order(orderId, new ArrayList<>(items), total, priority);
        orderQueue.enqueue(newOrder);
        
        return Optional.of(newOrder);
    }
    
    public Optional<Order> processNextOrder() {
        if (orderQueue.isEmpty()) {
            return Optional.empty();
        }
        
        Order order = orderQueue.dequeue();
        order.setStatus("preparing");
        
        // Deduct inventory
        if (deductInventoryForOrder(order)) {
            orderHistory.add(order);
            return Optional.of(order);
        } else {
            // If inventory deduction fails, re-queue the order
            orderQueue.enqueue(order);
            return Optional.empty();
        }
    }
    
    public void completeOrder(Order order) {
        order.setStatus("completed");
    }
    
    public void cancelOrder(Order order) {
        order.setStatus("cancelled");
        // Return inventory if needed
        returnInventoryForOrder(order);
    }
    
    private boolean deductInventoryForOrder(Order order) {
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            if (product.getIngredients() != null) {
                for (Map.Entry<String, Integer> ingredient : product.getIngredients().entrySet()) {
                    InventoryItem inventoryItem = inventory.get(ingredient.getKey());
                    if (inventoryItem == null || inventoryItem.getCurrentStock() < ingredient.getValue() * item.getQuantity()) {
                        return false; // Not enough stock
                    }
                }
            }
        }
        
        // Actually deduct the inventory
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            if (product.getIngredients() != null) {
                for (Map.Entry<String, Integer> ingredient : product.getIngredients().entrySet()) {
                    InventoryItem inventoryItem = inventory.get(ingredient.getKey());
                    inventoryItem.useStock(ingredient.getValue() * item.getQuantity());
                }
            }
        }
        
        return true;
    }
    
    private void returnInventoryForOrder(Order order) {
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            if (product.getIngredients() != null) {
                for (Map.Entry<String, Integer> ingredient : product.getIngredients().entrySet()) {
                    InventoryItem inventoryItem = inventory.get(ingredient.getKey());
                    inventoryItem.restock(ingredient.getValue() * item.getQuantity());
                }
            }
        }
    }
    
    // === INVENTORY MANAGEMENT ===
    public Map<String, InventoryItem> getInventory() {
        return new HashMap<>(inventory);
    }
    
    public Optional<InventoryItem> getInventoryItem(String name) {
        return Optional.ofNullable(inventory.get(name));
    }
    
    public boolean restockItem(String itemName, int quantity) {
        InventoryItem item = inventory.get(itemName);
        if (item != null) {
            // Save undo action
            undoStack.push(new AdminAction("RESTOCK", 
                new RestockData(itemName, item.getCurrentStock(), quantity), 
                "Restocked " + quantity + " " + itemName));
                
            item.restock(quantity);
            return true;
        }
        return false;
    }
    
    public List<InventoryItem> getLowStockItems() {
        return inventory.values().stream()
                .filter(InventoryItem::isLowStock)
                .collect(Collectors.toList());
    }
    
    // === MENU MANAGEMENT ===
    public ObservableList<Product> getMenuItems() { 
        return menuItems; 
    }
    
    public boolean addMenuItem(Product product) {
        if (menuItems.stream().anyMatch(p -> p.getId().equals(product.getId()))) {
            return false;
        }
        menuItems.add(product);
        
        // Add to undo stack
        undoStack.push(new AdminAction("ADD_MENU_ITEM", product, "Added menu item: " + product.getName()));
        return true;
    }
    
    public boolean deleteMenuItem(String productId) {
        Optional<Product> deletedProduct = menuItems.stream()
                .filter(p -> p.getId().equals(productId))
                .findFirst();

        if (deletedProduct.isPresent()) {
            menuItems.remove(deletedProduct.get());
            
            // Add to undo stack
            undoStack.push(new AdminAction("DELETE_MENU_ITEM", deletedProduct.get(), 
                "Deleted menu item: " + deletedProduct.get().getName()));
            return true;
        }
        return false;
    }
    
    public boolean updateMenuItem(Product updatedProduct) {
        for (int i = 0; i < menuItems.size(); i++) {
            if (menuItems.get(i).getId().equals(updatedProduct.getId())) {
                Product oldProduct = menuItems.get(i);
                menuItems.set(i, updatedProduct);
                
                // Add to undo stack
                undoStack.push(new AdminAction("UPDATE_MENU_ITEM", oldProduct, 
                    "Updated menu item: " + updatedProduct.getName()));
                return true;
            }
        }
        return false;
    }
    
    // === ORDER QUEUE ACCESS ===
    public PriorityQueue getOrderQueue() { 
        return orderQueue; 
    }
    
    public List<Order> getOrderHistory() { 
        return new ArrayList<>(orderHistory); 
    }
    
    public List<Order> getPendingOrders() {
        return orderQueue.toList();
    }
    
    // === UNDO FUNCTIONALITY ===
    public boolean canUndo() { 
        return !undoStack.isEmpty(); 
    }
    
    public String undoLastAction() {
        if (!canUndo()) { 
            return "No actions to undo."; 
        }
        
        AdminAction action = undoStack.pop();
        
        switch (action.getType()) {
            case "DELETE_MENU_ITEM":
                menuItems.add((Product) action.getData());
                return "Restored menu item: " + ((Product) action.getData()).getName();
                
            case "ADD_MENU_ITEM":
                menuItems.remove((Product) action.getData());
                return "Removed menu item: " + ((Product) action.getData()).getName();
                
            case "UPDATE_MENU_ITEM":
                Product oldProduct = (Product) action.getData();
                updateMenuItem(oldProduct); // This will re-push to stack, so we need to pop again
                undoStack.pop(); // Remove the redo action
                return "Reverted menu item changes: " + oldProduct.getName();
                
            case "RESTOCK":
                RestockData restockData = (RestockData) action.getData();
                InventoryItem item = inventory.get(restockData.getItemName());
                if (item != null) {
                    item.setCurrentStock(restockData.getOldStock());
                }
                return "Undid restock of " + restockData.getItemName();
                
            default:
                return "Unknown action type: " + action.getType();
        }
    }
    
    // === STATISTICS ===
    public double getTotalRevenue() {
        return orderHistory.stream()
                .filter(order -> "completed".equals(order.getStatus()))
                .mapToDouble(Order::getTotal)
                .sum();
    }
    
    public long getCompletedOrdersCount() {
        return orderHistory.stream()
                .filter(order -> "completed".equals(order.getStatus()))
                .count();
    }
    
    // Helper class for restock undo data
    private static class RestockData {
        private final String itemName;
        private final int oldStock;
        private final int restockAmount;
        
        public RestockData(String itemName, int oldStock, int restockAmount) {
            this.itemName = itemName;
            this.oldStock = oldStock;
            this.restockAmount = restockAmount;
        }
        
        public String getItemName() { return itemName; }
        public int getOldStock() { return oldStock; }
        public int getRestockAmount() { return restockAmount; }
    }
    
    // User class
    public static class User {
        private String username;
        private String password;
        private String role;
        
        public User(String username, String password, String role) {
            this.username = username;
            this.password = password;
            this.role = role;
        }
        
        public String getUsername() { return username; }
        public String getPassword() { return password; }
        public String getRole() { return role; }
    }
}