/**
 * Foundational LinkedList class used as the underlying structure for the PriorityQueue.
 */

package com.bitesandbanter.datastructure;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class LinkedList<T> {
    protected Node<T> head;
    protected Node<T> tail;
    protected int size;

    public boolean isEmpty() { 
        return size == 0; 
    }
    
    public int size() {
        return size;
    }

    public void addToHead(T data) {
        Node<T> newNode = new Node<>(data);
        if (isEmpty()) { 
            head = tail = newNode; 
        } else { 
            newNode.setNext(head); 
            head = newNode; 
        } 
        size++;
    }

    public T removeFromHead() {
        if (isEmpty()) return null; 
        T data = head.getData(); 
        head = head.getNext(); 
        if (head == null) tail = null; 
        size--; 
        return data;
    }
    
    public void addToTail(T data) {
        Node<T> newNode = new Node<>(data);
        if (isEmpty()) {
            head = tail = newNode;
        } else {
            tail.setNext(newNode);
            tail = newNode;
        }
        size++;
    }
    
    public List<T> toList() {
        List<T> list = new ArrayList<>(); 
        Node<T> current = head; 
        while (current != null) { 
            list.add(current.getData()); 
            current = current.getNext(); 
        } 
        return list;
    }
    
    public Optional<T> removeNode(Predicate<T> condition) {
        if (isEmpty()) return Optional.empty();
        
        // Check if head matches the condition
        if (condition.test(head.getData())) {
            return Optional.of(removeFromHead());
        }
        
        // Traverse to find the node to remove
        Node<T> current = head;
        while (current.getNext() != null && !condition.test(current.getNext().getData())) {
            current = current.getNext();
        }
        
        if (current.getNext() != null) {
            Node<T> toRemove = current.getNext();
            current.setNext(toRemove.getNext());
            if (toRemove == tail) {
                tail = current;
            }
            size--;
            return Optional.of(toRemove.getData());
        }
        
        return Optional.empty();
    }
    
    public T peekFirst() {
        if (isEmpty()) return null;
        return head.getData();
    }
}