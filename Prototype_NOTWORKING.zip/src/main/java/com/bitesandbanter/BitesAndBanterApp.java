package com.bitesandbanter;

import com.bitesandbanter.service.DataService;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.io.IOException;

public class BitesAndBanterApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            // Initialize the Singleton Data Service
            DataService.getInstance();
            
            // Load customer ordering interface
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/bitesandbanter/fxml/CustomerOrder.fxml"));
            Parent root = loader.load();
            
            Scene scene = new Scene(root, 1000, 700);
            primaryStage.setTitle("Bites and Banter Ordering System");
            primaryStage.setScene(scene);
            primaryStage.setMinWidth(800);
            primaryStage.setMinHeight(600);
            primaryStage.show();
            
        } catch (IOException e) {
            showErrorAlert("Failed to load application", "Could not load the main interface: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            showErrorAlert("Application Error", "An unexpected error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @Override
    public void stop() {
        // Clean up resources when application closes
        System.out.println("Application is closing...");
    }

    public static void main(String[] args) {
        // Set better exception handling for JavaFX
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            System.err.println("Uncaught exception: " + throwable.getMessage());
            throwable.printStackTrace();
        });
        
        launch(args);
    }
}