/**
 * Defines a single Menu Item.
 * Fields correspond to menu item details in the original HTML.
 */

package com.bitesandbanter.model;

import java.util.Map;

public class Product {
    private String id;
    private String name;
    private double price;
    private String description;
    private Map<String, Integer> ingredients; 
    private String imagePath;

    public Product(String id, String name, double price, String description, Map<String, Integer> ingredients) {
        this(id, name, price, description, ingredients, "");
    }
    
    public Product(String id, String name, double price, String description, Map<String, Integer> ingredients, String imagePath) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.ingredients = ingredients;
        this.imagePath = imagePath;
    }
    
    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public Map<String, Integer> getIngredients() { return ingredients; }
    public void setIngredients(Map<String, Integer> ingredients) { this.ingredients = ingredients; }
    
    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }
    
    @Override
    public String toString() {
        return name + " - ₱" + price;
    }
}