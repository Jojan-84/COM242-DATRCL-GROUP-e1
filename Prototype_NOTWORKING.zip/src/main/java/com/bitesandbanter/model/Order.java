/**
 * Represents a complete Order in the system (used by the PriorityQueue and Admin Table).
 */

package com.bitesandbanter.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class Order {
    private String id;
    private List<OrderItem> items;
    private double total;
    private String status;   // e.g., "new", "preparing", "completed"
    private int priority;    // 1 (High) is processed before 3 (Low)
    private LocalDateTime timestamp;

    public Order(String id, List<OrderItem> items, double total, int priority) {
        this.id = id;
        this.items = items;
        this.total = total;
        this.priority = priority;
        this.status = "new";
        this.timestamp = LocalDateTime.now();
    }
    
    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public List<OrderItem> getItems() { return items; }
    public void setItems(List<OrderItem> items) { this.items = items; }
    
    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
    
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    
    public String getPriorityText() {
        return switch (priority) {
            case 1 -> "High";
            case 2 -> "Medium";
            case 3 -> "Low";
            default -> "Unknown";
        };
    }
    
    public String getFormattedTimestamp() {
        return timestamp.format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm"));
    }
    
    public int getTotalItems() {
        return items.stream().mapToInt(OrderItem::getQuantity).sum();
    }
}