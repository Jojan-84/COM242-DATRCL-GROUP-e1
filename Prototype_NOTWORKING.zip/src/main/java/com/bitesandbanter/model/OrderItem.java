/**
 * Represents a single line item in a customer's cart or a final order.
 */

package com.bitesandbanter.model;

public class OrderItem {
    private Product product;
    private int quantity;

    public OrderItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }
    
    // Getters and Setters
    public Product getProduct() { return product; }
    public void setProduct(Product product) { this.product = product; }
    
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    
    public double getSubTotal() { 
        return product.getPrice() * quantity; 
    }
    
    @Override
    public String toString() {
        return quantity + " x " + product.getName() + " - ₱" + getSubTotal();
    }
}