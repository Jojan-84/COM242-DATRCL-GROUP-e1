package com.bitesandbanter.controller;

import com.bitesandbanter.model.InventoryItem;
import com.bitesandbanter.service.DataService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import java.util.Map;

/**
 * Controller for the Inventory Management screen.
 */
public class InventoryController {
    
    private final DataService dataService = DataService.getInstance();
    
    @FXML private VBox inventoryContainer;
    @FXML private Button undoRestockButton;

    @FXML
    public void initialize() {
        renderInventoryItems();
    }
    
    private void renderInventoryItems() {
        inventoryContainer.getChildren().clear();
        
        Map<String, InventoryItem> inventory = dataService.getInventory();
        for (InventoryItem item : inventory.values()) {
            VBox itemCard = createInventoryCard(item);
            inventoryContainer.getChildren().add(itemCard);
        }
    }
    
    private VBox createInventoryCard(InventoryItem item) {
        VBox card = new VBox(8);
        card.setStyle("-fx-background-color: white; -fx-border-color: #dddddd; -fx-border-radius: 12; -fx-padding: 15;");
        
        Label nameLabel = new Label(item.getName());
        nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");
        
        Label stockLabel = new Label("Stock: " + item.getCurrentStock());
        stockLabel.setStyle(item.isLowStock() ? "-fx-text-fill: red; -fx-font-weight: bold;" : "-fx-text-fill: green;");
        
        Label minLabel = new Label("(Min: " + item.getMinStock() + ")");
        minLabel.setStyle("-fx-text-fill: #666;");
        
        HBox buttonBox = new HBox(10);
        
        Button editBtn = new Button("Edit");
        editBtn.setStyle("-fx-background-color: #007bff; -fx-text-fill: white;");
        editBtn.setOnAction(e -> handleEditItem(item));
        
        Button restockBtn = new Button("Restock");
        restockBtn.setStyle("-fx-background-color: #28a745; -fx-text-fill: white;");
        restockBtn.setOnAction(e -> handleRestockItem(item));
        
        buttonBox.getChildren().addAll(editBtn, restockBtn);
        card.getChildren().addAll(nameLabel, stockLabel, minLabel, buttonBox);
        
        return card;
    }
    
    private void handleEditItem(InventoryItem item) {
        // Open edit dialog for inventory item
        showAlert("Edit", "Editing inventory item: " + item.getName());
    }
    
    private void handleRestockItem(InventoryItem item) {
        // Implement restock logic
        item.restock(25); // Example: restock 25 units
        renderInventoryItems();
        showAlert("Restocked", "Restocked 25 units of " + item.getName());
    }
    
    @FXML
    private void handleUndoRestock(ActionEvent event) {
        // Implement undo restock logic
        showAlert("Undo", "Undo last restock feature would be implemented here.");
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}