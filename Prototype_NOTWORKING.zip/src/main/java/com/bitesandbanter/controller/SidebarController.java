package com.bitesandbanter.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Controller for the sidebar navigation
 */
public class SidebarController {
    
    @FXML
    private void handleDashboard(ActionEvent event) {
        navigateTo("/com/bitesandbanter/fxml/Dashboard.fxml", "Bites & Banter - Dashboard");
    }
    
    @FXML
    private void handleOrders(ActionEvent event) {
        // Would navigate to Orders management screen
        showAlert("Navigation", "Orders management screen would open here.");
    }
    
    @FXML
    private void handleInventory(ActionEvent event) {
        navigateTo("/com/bitesandbanter/fxml/Homepage.fxml", "Bites & Banter - Inventory Management");
    }
    
    @FXML
    private void handleMenu(ActionEvent event) {
        navigateTo("/com/bitesandbanter/fxml/Menu.fxml", "Bites & Banter - Menu Management");
    }
    
    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            // Return to customer order screen
            DataService.getInstance().logout();
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/bitesandbanter/fxml/CustomerOrder.fxml"));
            Parent root = loader.load();
            
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 1000, 700));
            stage.setTitle("Bites & Banter - Order");
            stage.show();
            
        } catch (IOException e) {
            showAlert("Navigation Error", "Failed to logout: " + e.getMessage());
        }
    }
    
    private void navigateTo(String fxmlPath, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();
            
            Stage stage = (Stage) ((javafx.scene.Node) ((ActionEvent) event).getSource()).getScene().getWindow();
            stage.setScene(new Scene(root, 1200, 600));
            stage.setTitle(title);
            stage.show();
            
        } catch (IOException e) {
            showAlert("Navigation Error", "Failed to load " + title + ": " + e.getMessage());
        }
    }
    
    private void showAlert(String title, String message) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}