package com.bitesandbanter.controller;

import com.bitesandbanter.model.Product;
import com.bitesandbanter.service.DataService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * Controller for the Admin Menu Management screen (Menu.fxml).
 */
public class MenuController {
    
    private final DataService dataService = DataService.getInstance();
    
    @FXML private FlowPane menuFlowPane;
    @FXML private Button addMenuItemButton;
    @FXML private Button undoButton;

    @FXML
    public void initialize() {
        renderMenuItems();
        updateUndoButtonState();
    }
    
    public void renderMenuItems() {
        menuFlowPane.getChildren().clear();
        dataService.getMenuItems().forEach(item -> {
            VBox card = createMenuItemCard(item);
            menuFlowPane.getChildren().add(card);
        });
    }
    
    private VBox createMenuItemCard(Product item) {
        VBox card = new VBox(8);
        card.setStyle("-fx-background-color: white; -fx-border-color: #dddddd; -fx-border-radius: 12; -fx-padding: 10;");
        
        Label nameLabel = new Label(item.getName());
        nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");
        
        Label priceLabel = new Label(String.format("₱%.2f", item.getPrice()));
        priceLabel.setStyle("-fx-font-size: 14px;");
        
        Label descLabel = new Label(item.getDescription());
        descLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #555;");
        descLabel.setWrapText(true);
        
        HBox buttonBox = new HBox(10);
        Button editBtn = new Button("Edit");
        editBtn.setStyle("-fx-background-color: #007bff; -fx-text-fill: white; -fx-background-radius: 5;");
        editBtn.setOnAction(e -> handleEditItem(item));
        
        Button deleteBtn = new Button("Delete");
        deleteBtn.setStyle("-fx-background-color: #dc3545; -fx-text-fill: white; -fx-background-radius: 5;");
        deleteBtn.setOnAction(e -> handleDeleteItem(item));
        
        buttonBox.getChildren().addAll(editBtn, deleteBtn);
        card.getChildren().addAll(nameLabel, priceLabel, descLabel, buttonBox);
        
        return card;
    }

    @FXML
    private void handleAddMenuItem(ActionEvent event) {
        // Open dialog to add new menu item
        showAlert("Info", "Add Menu Item feature would open a dialog here.");
    }
    
    private void handleEditItem(Product item) {
        // Open dialog to edit menu item
        showAlert("Info", "Editing: " + item.getName());
    }
    
    private void handleDeleteItem(Product item) {
        if (dataService.deleteMenuItem(item.getId())) {
            renderMenuItems();
            updateUndoButtonState();
            showAlert("Success", "Menu item deleted: " + item.getName());
        }
    }
    
    @FXML
    private void handleUndoAction(ActionEvent event) {
        String result = dataService.undoLastAdminAction();
        renderMenuItems();
        updateUndoButtonState();
        showAlert("Undo", result);
    }
    
    private void updateUndoButtonState() {
        undoButton.setDisable(!dataService.canUndo());
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}