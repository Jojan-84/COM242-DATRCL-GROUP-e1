package com.bitesandbanter.controller;

import com.bitesandbanter.model.Product;
import com.bitesandbanter.model.OrderItem;
import com.bitesandbanter.service.DataService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

/**
 * Main Controller for Customer Order Interface
 */
public class BitesAndBanterController {

    private final DataService dataService = DataService.getInstance();
    private final ObservableList<Product> menuItems = dataService.getMenuItems();
    private final ObservableList<OrderItem> currentOrderItems = FXCollections.observableArrayList();

    // FXML Bindings for CustomerOrder.fxml
    @FXML private VBox menuItemsContainer;
    @FXML private ListView<OrderItem> orderList;
    @FXML private Label orderTotal;
    @FXML private Button placeOrderBtn;
    @FXML private Button adminLoginBtn;

    @FXML
    public void initialize() {
        setupCustomerView(); 
        updateOrderSummary();
        orderList.setItems(currentOrderItems);
        
        // Set up order list cell factory for better display
        orderList.setCellFactory(param -> new ListCell<OrderItem>() {
            @Override
            protected void updateItem(OrderItem item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getQuantity() + " x " + item.getProduct().getName() + " - ₱" + item.getSubTotal());
                }
            }
        });
    }
    
    private void setupCustomerView() {
        menuItemsContainer.getChildren().clear();
        for (Product item : menuItems) {
            VBox itemBox = createMenuItemBox(item);
            menuItemsContainer.getChildren().add(itemBox);
        }
    }
    
    private VBox createMenuItemBox(Product item) {
        VBox itemBox = new VBox(8);
        itemBox.setStyle("-fx-padding: 15; -fx-border-color: #e0e0e0; -fx-border-radius: 8; -fx-background-color: white;");
        itemBox.setPrefWidth(250);
        
        Label nameLabel = new Label(item.getName());
        nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");
        
        Label priceLabel = new Label(String.format("₱%.2f", item.getPrice()));
        priceLabel.setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
        
        Label descLabel = new Label(item.getDescription());
        descLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #666;");
        descLabel.setWrapText(true);
        descLabel.setMaxWidth(200);
        
        HBox quantityBox = new HBox(10);
        quantityBox.setStyle("-fx-alignment: CENTER_LEFT;");
        
        Label qtyLabel = new Label("Quantity:");
        Spinner<Integer> quantitySpinner = new Spinner<>(0, 99, 0);
        quantitySpinner.setId("qty-" + item.getId());
        quantitySpinner.valueProperty().addListener((obs, oldVal, newVal) -> updateOrderSummary());
        
        quantityBox.getChildren().addAll(qtyLabel, quantitySpinner);
        itemBox.getChildren().addAll(nameLabel, priceLabel, descLabel, quantityBox);
        
        return itemBox;
    }

    private void updateOrderSummary() {
        double total = 0;
        currentOrderItems.clear(); 
        
        for (Product item : menuItems) {
            Spinner<Integer> spinner = (Spinner<Integer>) menuItemsContainer.lookup("#qty-" + item.getId());
            if (spinner != null && spinner.getValue() > 0) {
                OrderItem orderItem = new OrderItem(item, spinner.getValue());
                currentOrderItems.add(orderItem);
                total += orderItem.getSubTotal();
            }
        }
        orderTotal.setText(String.format("₱%.2f", total));
        placeOrderBtn.setDisable(total == 0);
    }
    
    // Event Handlers
    @FXML 
    private void handleAdminLogin(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/bitesandbanter/fxml/Adminlogin.fxml"));
            Parent root = loader.load();
            
            Stage stage = (Stage) adminLoginBtn.getScene().getWindow();
            stage.setScene(new Scene(root, 450, 350));
            stage.setTitle("Bites & Banter - Admin Login");
            stage.show();
            
        } catch (Exception e) {
            showAlert("Navigation Error", "Failed to load admin login: " + e.getMessage());
        }
    }
    
    @FXML
    private void handlePlaceOrder(ActionEvent event) {
        if (currentOrderItems.isEmpty()) {
            showAlert("Order Error", "Please add items to your order before placing it.");
            return;
        }
        
        List<OrderItem> itemsToOrder = new ArrayList<>(currentOrderItems);
        dataService.placeOrder(itemsToOrder).ifPresent(order -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Order Placed");
            alert.setHeaderText("Order #" + order.getId() + " placed successfully!");
            alert.setContentText(String.format("Total: ₱%.2f\nPriority: %s\nEstimated wait time: %d minutes", 
                order.getTotal(), order.getPriorityText(), getEstimatedWaitTime(order.getPriority())));
            alert.showAndWait();
            
            // Reset order
            resetOrderForm();
        });
    }
    
    private int getEstimatedWaitTime(int priority) {
        switch (priority) {
            case 1: return 10; // High priority - 10 minutes
            case 2: return 20; // Medium priority - 20 minutes  
            case 3: return 30; // Low priority - 30 minutes
            default: return 25;
        }
    }
    
    private void resetOrderForm() {
        // Reset all spinners to 0
        menuItemsContainer.getChildren().forEach(node -> {
            if (node instanceof VBox) {
                ((VBox) node).getChildren().stream()
                    .filter(child -> child instanceof Spinner)
                    .forEach(child -> ((Spinner<Integer>) child).getValueFactory().setValue(0));
            }
        });
        updateOrderSummary();
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}