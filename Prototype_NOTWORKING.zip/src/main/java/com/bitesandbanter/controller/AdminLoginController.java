package com.bitesandbanter.controller;

import com.bitesandbanter.service.DataService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Controller for the Admin Login screen (Adminlogin.fxml).
 */
public class AdminLoginController {
    
    private final DataService dataService = DataService.getInstance();
    
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    @FXML
    private void handleLogin(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();
        
        if (dataService.authenticateUser(username, password)) {
            try {
                // Load admin dashboard
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/bitesandbanter/fxml/Dashboard.fxml"));
                Parent root = loader.load();
                
                Stage stage = (Stage) usernameField.getScene().getWindow();
                stage.setScene(new Scene(root, 1200, 600));
                stage.setTitle("Bites & Banter - Admin Dashboard");
                stage.show();
                
            } catch (IOException e) {
                showAlert("Error", "Failed to load admin dashboard: " + e.getMessage());
            }
        } else {
            showAlert("Login Failed", "Invalid username or password.");
            passwordField.clear();
        }
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}