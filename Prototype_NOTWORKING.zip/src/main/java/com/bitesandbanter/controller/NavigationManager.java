package com.bitesandbanter.controller;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Manages navigation between different scenes in the application.
 */
public class NavigationManager {
    
    public static void showCustomerOrder(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(NavigationManager.class.getResource("/com/bitesandbanter/fxml/CustomerOrder.fxml"));
        Parent root = loader.load();
        stage.setScene(new Scene(root, 1000, 700));
        stage.setTitle("Bites & Banter - Order");
        stage.show();
    }
    
    public static void showAdminDashboard(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(NavigationManager.class.getResource("/com/bitesandbanter/fxml/Dashboard.fxml"));
        Parent root = loader.load();
        stage.setScene(new Scene(root, 1200, 600));
        stage.setTitle("Bites & Banter - Admin Dashboard");
        stage.show();
    }
    
    public static void showAdminLogin(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(NavigationManager.class.getResource("/com/bitesandbanter/fxml/Adminlogin.fxml"));
        Parent root = loader.load();
        stage.setScene(new Scene(root, 450, 350));
        stage.setTitle("Bites & Banter - Admin Login");
        stage.show();
    }
    
    public static void showMenuManagement(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(NavigationManager.class.getResource("/com/bitesandbanter/fxml/Menu.fxml"));
        Parent root = loader.load();
        stage.setScene(new Scene(root, 1200, 600));
        stage.setTitle("Bites & Banter - Menu Management");
        stage.show();
    }
    
    public static void showInventoryManagement(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(NavigationManager.class.getResource("/com/bitesandbanter/fxml/Homepage.fxml"));
        Parent root = loader.load();
        stage.setScene(new Scene(root, 1200, 600));
        stage.setTitle("Bites & Banter - Inventory Management");
        stage.show();
    }
}