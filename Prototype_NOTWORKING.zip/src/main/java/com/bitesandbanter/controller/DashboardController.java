package com.bitesandbanter.controller;

import com.bitesandbanter.service.DataService;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {
    
    private final DataService dataService = DataService.getInstance();
    
    @FXML private Label totalEarningsLabel;
    @FXML private Label pendingOrdersLabel; 
    @FXML private Label completedOrdersLabel;
    @FXML private Label lowStockCountLabel;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        updateDashboardStats();
    }
    
    private void updateDashboardStats() {
        double totalEarnings = dataService.getTotalRevenue();
        int pendingOrders = dataService.getPendingOrders().size();
        int completedOrders = (int) dataService.getCompletedOrdersCount();
        int lowStockItems = dataService.getLowStockItems().size();
        
        totalEarningsLabel.setText(String.format("₱%.2f", totalEarnings));
        pendingOrdersLabel.setText(String.valueOf(pendingOrders));
        completedOrdersLabel.setText(String.valueOf(completedOrders));
        lowStockCountLabel.setText(String.valueOf(lowStockItems));
    }
    
    @FXML
    private void handleRefresh() {
        updateDashboardStats();
    }
}